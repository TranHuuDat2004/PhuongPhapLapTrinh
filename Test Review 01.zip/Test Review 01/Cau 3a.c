#include<stdio.h>
#include<math.h>

// tim trung binh bang de quy

double average(int arr[], int count){
	double trung_binh; 
	// base case
	if ( count == 1)
		return arr[0];
	// recursive case
	else if (count > 1)
		return average(arr, count - 1)/ (count - 1);
}
	


int main(){
	int arr[] = {1, 2, 3, 4, 5};
	double result = average(arr, 5);
	printf("Expected: %d, Actual %.2lf", 3, result);
	return 0;
}
