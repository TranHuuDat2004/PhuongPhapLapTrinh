#include <stdio.h>
#include <math.h>
#define PI 3.1415926535

// Weather Wind
void wind  (int n, double nbc, double nbg, int ld, int dc, int dg, int bc, int bg, double nd){
	FILE *outfile = fopen("output.out", "w");

	int banh; // so banh tong cong
	int thua; // so banh thua
	bc = n / nbc;
	bg = (n - bc*nbc) / nbg;
	// do dai canh > duong kinh
	if (dc > dg){   
		bc = n / nbc;
		if (ld <= bc){		// la dong <= banh chung
			thua = bc - ld;
			bc = bc - thua;  // thay doi banh chung
			bg = 0;
			nd = n - bc*nbc; 

			// case 200 5 6 5 Wind dung		
			// case 337 6 4 9 Wind dung	
		}
		else if (ld > bc) {	// la dong > banh chung
			thua = ld - bc;
			bg = (n - bc*nbc) / nbg;
			if(thua < bc)
				bg = bg - thua;
			nd = n - bc*nbc - bg*nbg;
			
			// case 485 9 5 7 Wind dung	
		}		
		else {
			bg = (n - bc*nbc) / nbg;
			nd = n - bc*nbc - bg*nbg;
			
		}
	}
	// do dai canh < duong kinh	
	else if (dc < dg){	
		bg = n / nbg;
		if (ld <= bg){		// la dong <= banh giay
			thua = bg - ld;
			bg = bg - thua;  // thay doi banh chung
			bc = 0;
			nd = n - bg*nbg;  
		
			// case 200 5 6 5 Wind dung	
		}
		else if ( (n - (bc-1)*nbc ) < nbg){  // uu tien nep du toi thieu
			bg = (n - bc*nbc) / nbg;
			nd = n - bc*nbc - bg*nbg; 

			// case 152 5 6 20 Wind dung	
			}
		else if ((n - (bc+1)*nbc) < nbg){
			bc = bc - 1;
			bg = (n - bc*nbc) / nbg;
			nd = n - bc*nbc - bg*nbg;
			
			// case 155 5 6 20 Wind dung	
		}
	
		else {
			bc = (n - bg*nbg) / nbc;
			nd = n - bc*nbc - bg*nbg;
			
		}
		
	}
	
	// xuat file
//	printf("%lf\n",nd);
	fprintf(outfile, "%d %d %.3lf", bc, bg, nd);
	fclose(outfile);
		
}// ket thuc Weather Wind

// Weather Rain
void rain  (int n, double nbc, double nbg, int ld, int dc, int dg, int bc, int bg, double nd){
	FILE *outfile = fopen("output.out", "w");
	int sobanh; 	// so luong banh cho ca hai loai
	sobanh = n / (nbc+nbg);
	bc = sobanh;
	bg = sobanh;
	nd = n - bc*nbc - bg*nbg;
	while (nd > nbc){
		bc = bc + 1;
		nd = n - bc*nbc - bg*nbg; // thay doi banh giay
	}
	while (nd > nbg){
		bg = bg + 1;
		nd = n - bc*nbc - bg*nbg; // thay doi banh giay
	}
	while (ld < ( bc+bg)){
		bc --;
		if(ld == (bc+bg)) break;
		bg --;
		if(ld == (bc+bg)) break;
	}	
	nd = n - bc*nbc - bg*nbg;
		
	// xuat file
	fprintf(outfile, "%d %d %.3lf", bc, bg, nd);
	fclose(outfile);
	
} // ket thuc Weather Rain

// Weather Cloud
void cloud (int n, double nbc, double nbg, int ld, int dc, int dg, int bc, int bg, double nd){
	FILE *outfile = fopen("output.out", "w");		
	// so nep va la dong la so ban be
	if ( (n == 220 && ld == 284) || (n == 284 && ld == 220) ){
		bc = 0; 
		bg = 0;
		nd = n;
	}
		
	// lam nhieu banh giay
	else{
		bg = n / nbg;
		int thua; // so banh thua
		
		if (ld < bg){		
			thua = bg - ld;
			bg = bg - thua;  // thay doi banh giay
			bc = 0;
			nd = n - bg*nbg;
		}
		
		else{
			thua = ld - bg;
			bc = (n - bg*nbg) / nbc;
			bc = bc - thua; // thay doi banh chung
			nd = n - bc*nbc - bg*nbg;
		}
	}
	// xuat file
	fprintf(outfile, "%d %d %.3lf", bc, bg, nd);
	fclose(outfile);
} // ket thuc Weather Cloud

// Weather Sun
void sun   (int n, double nbc, double nbg, int ld, int dc, int dg, int bc, int bg, double nd){
	FILE *outfile = fopen("output.out", "w");
	int G; 		// phan du do dai canh (dc) banh chung
	int H;		// phan du la dong (ld) 
	int x;		//  phan tram tang them nep va giam la dong 
	int hieu;  // goi hieu = G - H
		
	G = dc % 6;
	H = ld % 5;
	hieu = G - H; 
		
	if 		(hieu == 0)					x = 5;			
	else if (hieu == 1) 				x = 7;	
	else if (hieu == 2 || hieu == -4)	x = 10;		
	else if (hieu == 3 || hieu == -3)	x = 12;		
	else if (hieu == 4 || hieu == -2)	x = 15;		
	else if (hieu == 5 || hieu == -1)	x = 20;
			
	// thay doi nep, la dong
	n = n + (n * x/100) ;
	ld = ld - (ld * x/100);
		
	// thay doi thoi tiet
	int weather;
	weather = (dc+dg)%3;
		
	//Rain
	if (weather == 0)
		rain  (n, nbc, nbg, ld, dc, dg, bc, bg, nd);
			
	// Wind
	else if (weather == 1)
		wind  (n, nbc, nbg, ld, dc, dg, bc, bg, nd);
		
	// Cloud
	else if (weather == 2)
		cloud (n, nbc, nbg, ld, dc, dg, bc, bg, nd);
	
	// xuat file
	fprintf(outfile, "%d %d %.3lf", bc, bg, nd);
	fclose(outfile);

	} // ket thuc Weather Sun

// Weather Fog
void fog   (int n, double nbc, double nbg, int ld, int dc, int dg, int bc, int bg, double nd){	
	FILE *outfile = fopen("output.out", "w");
	bc = dc; 	// banh chung = do dai canh
	bg = dg; 	// banh giay = duong kinh
	nd = n;

	// xuat file
	fprintf(outfile, "%d %d %.3lf", bc, bg, nd);
	fclose(outfile);
}

// Main
int main() {
	FILE *infile, *outfile; // bien nhap - xuat file
	
	// nep, do dai canh, duong kinh, la dong, thoi tiet
	int n, dc, dg, ld;
	char w[10];
	
	// ten input - output
	infile = fopen("input.inp", "r");
	outfile = fopen("output.out", "w");
	
	// nhap file
	fscanf(infile, "%d %d %d %d %s", &n, &dc, &dg, &ld, &w);
	fclose(infile);
	
	// sai du lieu
	if (infile == NULL || n >=1000 || n < 0 || dc < 0 || dg < 0 || ld > 300 || ld < 1){
		fprintf(outfile, "-1 -1 %d", n);
		return 0;
	}
	
	// banh chung, banh giay, nep du
	int bc, bg;
	double nd;
	
	// so banh can dung de xai la dong, so nep xai banh chung, banh giay
	int banh;
	double nbc, nbg;
	
	// cong thuc tinh so nep can dung cua banh chung, banh giay
	nbc = pow(dc, 2);
	nbg = (pow(dg, 2)*PI) / 4;
	
	// Weather Wind
	if (strcmp(w,"Wind") == 0)
		wind (n, nbc, nbg, ld, dc, dg, bc, bg, nd); // theo thu tu nep, nep banh chung, nep banh giay, la dong
	
	// Weather Rain
	else if (strcmp(w,"Rain") == 0)		
		rain (n, nbc, nbg, ld, dc, dg, bc, bg, nd);
		
	// Weather Sun
	else if (strcmp(w,"Sun") == 0)
		sun (n, nbc, nbg, ld, dc, dg, bc, bg, nd);	
	
	// Weather Fog
	else if (strcmp(w,"Fog") == 0)
		fog (n, nbc, nbg, ld, dc, dg, bc, bg, nd);	
		
	// Weather Cloud
	else if (strcmp(w,"Cloud") == 0)
		cloud (n, nbc, nbg, ld, dc, dg, bc, bg, nd);	

	// Sai thoi tiet
	else {
		fprintf(outfile, "-1 -1 %d", n);
		return 0;
	}
	

	
}// ket thuc main
