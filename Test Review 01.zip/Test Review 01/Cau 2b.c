#include <stdio.h>
int main(){
	int i = 0;
	printf("%d", i++);  // print i = 0; i = 1 do i++
	printf("%d", ++i);  // i = 2 do ++i; print i = 2
	return 0;
}
